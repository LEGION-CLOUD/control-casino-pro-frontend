const express = require('express');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');

const app = express();
const PORT = 3001;
app.use(cors());
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
if(!fs.existsSync('uploads')) fs.mkdirSync('uploads');

const db = new Database('casino.db');
db.pragma('foreign_keys = OFF');
db.exec(`
  CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE, password_hash TEXT, nombre TEXT, role TEXT DEFAULT 'cajero', created_at TEXT);
  CREATE TABLE IF NOT EXISTS clientes (id INTEGER PRIMARY KEY AUTOINCREMENT, codigo TEXT UNIQUE, nombre TEXT, telefono TEXT, saldo REAL DEFAULT 0, created_by INTEGER, created_at TEXT);
  CREATE TABLE IF NOT EXISTS operaciones (id INTEGER PRIMARY KEY AUTOINCREMENT, numero TEXT UNIQUE, cliente_id INTEGER, cliente TEXT, tipo TEXT, monto REAL, fecha TEXT, hora TEXT, estado TEXT, medio TEXT, banco TEXT, comprobante_file TEXT, cajera TEXT, user_id INTEGER, observaciones TEXT, fecha_iso TEXT);
  CREATE TABLE IF NOT EXISTS cierres (id INTEGER PRIMARY KEY AUTOINCREMENT, fecha TEXT, total_recibido REAL, total_entregado REAL, saldo REAL, total_ops INTEGER, cajera TEXT, user_id INTEGER, detalle TEXT, saldo_sistema REAL, arqueo_real REAL, diferencia REAL, estado_arqueo TEXT);
  CREATE TABLE IF NOT EXISTS auditoria (id INTEGER PRIMARY KEY AUTOINCREMENT, fecha_iso TEXT, fecha TEXT, hora TEXT, user_id INTEGER, usuario TEXT, rol TEXT, accion TEXT, elemento TEXT, detalle TEXT);
`);
try{
  const colsOps = db.prepare(`PRAGMA table_info(operaciones)`).all().map(c=>c.name);
  if(!colsOps.includes('fecha_iso')) db.exec(`ALTER TABLE operaciones ADD COLUMN fecha_iso TEXT`);
  const colsC = db.prepare(`PRAGMA table_info(cierres)`).all().map(c=>c.name);
  if(!colsC.includes('arqueo_real')) db.exec(`ALTER TABLE cierres ADD COLUMN arqueo_real REAL`);
  if(!colsC.includes('diferencia')) db.exec(`ALTER TABLE cierres ADD COLUMN diferencia REAL`);
  if(!colsC.includes('estado_arqueo')) db.exec(`ALTER TABLE cierres ADD COLUMN estado_arqueo TEXT`);
  if(!colsC.includes('saldo_sistema')) db.exec(`ALTER TABLE cierres ADD COLUMN saldo_sistema REAL`);
}catch(e){}

const adminExists = db.prepare('SELECT * FROM users WHERE username=?').get('admin');
if(!adminExists){ const hash=bcrypt.hashSync('admin123',10); db.prepare('INSERT INTO users (username,password_hash,nombre,role,created_at) VALUES (?,?,?,?,?)').run('admin',hash,'Administrador','admin',new Date().toISOString()); }

const storage = multer.diskStorage({ destination:'uploads/', filename:(req,file,cb)=>cb(null, Date.now()+'-'+file.originalname.replace(/\s+/g,'_')) });
const upload = multer({ storage, limits:{fileSize:5*1024*1024}, fileFilter:(req,file,cb)=>{ const allowed=['image/jpeg','image/png','image/webp','application/pdf']; if(allowed.includes(file.mimetype) || file.mimetype.startsWith('image/')) cb(null,true); else cb(new Error('Solo imagenes o PDF')); } });

function getUserById(id){ if(!id) return null; try{ return db.prepare('SELECT id, username, nombre, role FROM users WHERE id=?').get(Number(id)); }catch{ return null; } }
function getUserFullById(id){ if(!id) return null; try{ return db.prepare('SELECT * FROM users WHERE id=?').get(Number(id)); }catch{ return null; } }

function registrarAuditoria({user_id, usuario, rol, accion, elemento, detalle}){
  try{
    let nombreUsuario = usuario; let rolUsuario = rol || 'cajero';
    if((!nombreUsuario || !rolUsuario) && user_id){ const u = getUserById(user_id); if(u){ if(!nombreUsuario) nombreUsuario = u.nombre; if(!rol) rolUsuario = u.role; } }
    const now = new Date();
    db.prepare(`INSERT INTO auditoria (fecha_iso, fecha, hora, user_id, usuario, rol, accion, elemento, detalle) VALUES (?,?,?,?,?,?,?,?,?)`).run(now.toISOString(), now.toLocaleDateString('es-AR'), now.toLocaleTimeString('es-AR', {hour:'2-digit',minute:'2-digit',second:'2-digit'}), user_id||null, nombreUsuario||'Desconocido', rolUsuario, accion, elemento||'', detalle||'');
  }catch(e){ console.error('Error audit', e.message); }
}

function parseFechaES(fechaStr){
  try{ const [d,m,a] = fechaStr.split('/').map(Number); if(!d||!m||!a) return null; return new Date(a, m-1, d); }catch{ return null; }
}

app.post('/api/login', (req,res)=>{
  const {username,password}=req.body;
  if(!username || !password) return res.status(400).json({error:'Falta usuario o clave'});
  const u=db.prepare('SELECT * FROM users WHERE username=?').get(username.trim());
  if(!u) return res.status(401).json({error:'Usuario no existe'});
  if(!bcrypt.compareSync(password,u.password_hash)) return res.status(401).json({error:'Clave incorrecta'});
  const {password_hash,...safe}=u; res.json({ok:true,user:safe});
});

app.post('/api/register', (req,res)=>{
  const {username,password,nombre,role, created_by}=req.body;
  if(!username || !password || !nombre) return res.status(400).json({error:'Faltan datos'});
  if(password.length < 3) return res.status(400).json({error:'Clave muy corta min 3'});
  if(db.prepare('SELECT id FROM users WHERE username=?').get(username.trim().toLowerCase())) return res.status(400).json({error:'Usuario ya existe'});
  const creator = getUserById(created_by); if(!creator) return res.status(401).json({error:'Creador no valido'});
  if(creator.role !== 'admin' && role === 'admin') return res.status(403).json({error:'Una cajera no puede crear administradores'});
  const hash=bcrypt.hashSync(password,10);
  const info=db.prepare('INSERT INTO users (username,password_hash,nombre,role,created_at) VALUES (?,?,?,?,?)').run(username.trim().toLowerCase(),hash,nombre.trim(),role||'cajero',new Date().toISOString());
  registrarAuditoria({user_id: creator.id, usuario: creator.nombre, rol: creator.role, accion: 'CREAR USUARIO/CAJERA', elemento: username.trim().toLowerCase(), detalle: `Usuario creado: ${nombre} (${username}) rol ${role} por ${creator.nombre}`});
  res.json({ok:true,id:info.lastInsertRowid});
});

app.get('/api/users', (req,res)=>{
  const authUser = getUserById(req.query.user_id); if(!authUser) return res.status(401).json({error:'No autenticado'});
  if(authUser.role !== 'admin') return res.status(403).json({error:'Solo admin ve usuarios'});
  res.json(db.prepare('SELECT id,username,nombre,role,created_at FROM users ORDER BY id').all());
});

app.put('/api/users/:id/reset-password', (req,res)=>{
  const {newPassword, reset_by}=req.body; const resetByUser = getUserById(reset_by); if(!resetByUser) return res.status(401).json({error:'No autenticado'});
  if(resetByUser.role !== 'admin') return res.status(403).json({error:'Solo admin puede resetear claves'});
  if(!newPassword||newPassword.length<3) return res.status(400).json({error:'Clave muy corta min 3'});
  const target = db.prepare('SELECT username, nombre FROM users WHERE id=?').get(req.params.id); if(!target) return res.status(404).json({error:'Usuario no existe'});
  const hash=bcrypt.hashSync(newPassword,10); db.prepare('UPDATE users SET password_hash=? WHERE id=?').run(hash,req.params.id);
  registrarAuditoria({user_id: resetByUser.id, usuario: resetByUser.nombre, rol: resetByUser.role, accion: 'RESETEAR CONTRASEÑA', elemento: target.username, detalle: `Reseteo clave de ${target.nombre} (${target.username}) por ${resetByUser.nombre}`});
  res.json({ok:true});
});

app.put('/api/users/:id/change-password', (req,res)=>{
  const {currentPassword, newPassword}=req.body; const targetFull = getUserFullById(req.params.id); if(!targetFull) return res.status(404).json({error:'No existe'});
  if(!currentPassword || !newPassword) return res.status(400).json({error:'Faltan datos'});
  if(!bcrypt.compareSync(currentPassword, targetFull.password_hash)) return res.status(401).json({error:'Clave actual incorrecta'});
  if(newPassword.length<3) return res.status(400).json({error:'Nueva clave muy corta min 3'});
  const hash=bcrypt.hashSync(newPassword,10); db.prepare('UPDATE users SET password_hash=? WHERE id=?').run(hash, req.params.id);
  registrarAuditoria({user_id: targetFull.id, usuario: targetFull.nombre, rol: targetFull.role, accion: 'CAMBIAR MI CONTRASEÑA', elemento: targetFull.username, detalle: `Usuario ${targetFull.nombre} cambio su propia contrasena`});
  res.json({ok:true});
});

app.delete('/api/users/:id', (req,res)=>{
  const authUser = getUserById(req.query.user_id); if(!authUser) return res.status(401).json({error:'No autenticado'});
  if(authUser.role !== 'admin') return res.status(403).json({error:'Solo admin puede borrar usuarios'});
  const target = db.prepare('SELECT * FROM users WHERE id=?').get(req.params.id); if(!target) return res.status(404).json({error:'No existe'});
  if(target.username==='admin') return res.status(400).json({error:'No podes borrar al admin principal'});
  if(String(target.id)===String(authUser.id)) return res.status(400).json({error:'No podes borrarte a vos mismo'});
  db.prepare('DELETE FROM users WHERE id=?').run(req.params.id);
  registrarAuditoria({user_id: authUser.id, usuario: authUser.nombre, rol: authUser.role, accion: 'BORRAR USUARIO', elemento: target.username, detalle: `Usuario borrado: ${target.nombre} (${target.username}) rol ${target.role} por ${authUser.nombre}`});
  res.json({ok:true});
});

// CLIENTES
app.get('/api/clientes', (req,res)=>{
  const authUser = getUserById(req.query.user_id); if(!authUser) return res.status(401).json({error:'No autenticado'});
  // ETAPA 2 FIX: traer nombre del cajero que creó el cliente via JOIN
  res.json(db.prepare(`
    SELECT clientes.*, users.nombre as creador_nombre, users.username as creador_username 
    FROM clientes 
    LEFT JOIN users ON clientes.created_by = users.id 
    ORDER BY clientes.id DESC
  `).all());
});

app.post('/api/clientes', (req,res)=>{
  const {codigo,nombre,telefono,created_by}=req.body; const creator = getUserById(created_by); if(!creator) return res.status(401).json({error:'No autenticado'});
  if(!codigo || !nombre) return res.status(400).json({error:'Codigo y nombre obligatorios'});
  if(codigo.trim().length < 1 || nombre.trim().length < 2) return res.status(400).json({error:'Datos muy cortos'});
  try{
    db.prepare('INSERT INTO clientes (codigo,nombre,telefono,created_by,created_at) VALUES (?,?,?,?,?)').run(codigo.trim().toUpperCase(),nombre.trim(),telefono?telefono.trim():'',creator.id,new Date().toISOString());
    registrarAuditoria({user_id: creator.id, usuario: creator.nombre, rol: creator.role, accion: 'CREAR CLIENTE', elemento: codigo.trim().toUpperCase(), detalle: `Cliente ${nombre} codigo ${codigo} por ${creator.nombre}`});
    res.json({ok:true});
  }catch{ res.status(400).json({error:'Codigo ya existe'}); }
});

// ETAPA 2: EDITAR CLIENTE
app.put('/api/clientes/:id', (req,res)=>{
  const authUser = getUserById(req.body.user_id || req.query.user_id); if(!authUser) return res.status(401).json({error:'No autenticado'});
  const target = db.prepare('SELECT * FROM clientes WHERE id=?').get(req.params.id); if(!target) return res.status(404).json({error:'Cliente no existe'});
  if(authUser.role !== 'admin' && String(target.created_by) !== String(authUser.id)){
    return res.status(403).json({error:'Solo admin o quien creo el cliente puede editarlo'});
  }
  const {codigo,nombre,telefono}=req.body;
  if(!codigo || !nombre) return res.status(400).json({error:'Codigo y nombre obligatorios'});
  if(codigo.trim().length<1 || nombre.trim().length<2) return res.status(400).json({error:'Datos muy cortos'});
  try{
    db.prepare('UPDATE clientes SET codigo=?, nombre=?, telefono=? WHERE id=?').run(codigo.trim().toUpperCase(), nombre.trim(), telefono?telefono.trim():'', req.params.id);
    registrarAuditoria({user_id: authUser.id, usuario: authUser.nombre, rol: authUser.role, accion: 'EDITAR CLIENTE', elemento: codigo.trim().toUpperCase(), detalle: `Cliente editado: antes ${target.codigo} ${target.nombre} -> ahora ${codigo} ${nombre} por ${authUser.nombre}`});
    res.json({ok:true});
  }catch(e){
    if(e.message.includes('UNIQUE')) return res.status(400).json({error:'Codigo ya existe'});
    res.status(500).json({error:e.message});
  }
});

app.delete('/api/clientes/:id', (req,res)=>{
  const authUser = getUserById(req.query.user_id); if(!authUser) return res.status(401).json({error:'No autenticado'});
  if(authUser.role !== 'admin') return res.status(403).json({error:'Solo admin puede borrar clientes'});
  const target = db.prepare('SELECT * FROM clientes WHERE id=?').get(req.params.id); if(!target) return res.status(404).json({error:'No existe'});
  const opsConCliente = db.prepare('SELECT COUNT(*) as c FROM operaciones WHERE cliente_id=? OR cliente=?').get(target.id, target.codigo).c;
  if(opsConCliente>0) return res.status(400).json({error:`No podes borrar, tiene ${opsConCliente} operaciones.`});
  db.prepare('DELETE FROM clientes WHERE id=?').run(req.params.id);
  registrarAuditoria({user_id: authUser.id, usuario: authUser.nombre, rol: authUser.role, accion: 'BORRAR CLIENTE', elemento: target.codigo, detalle: `Cliente borrado: ${target.nombre} por ${authUser.nombre}`});
  res.json({ok:true});
});

// OPERACIONES CON FILTROS ETAPA 2
app.get('/api/operaciones', (req,res)=>{
  const authUser = getUserById(req.query.user_id); if(!authUser) return res.status(401).json({error:'No autenticado'});
  const {tipo, estado, cliente, cajera_id, desde, hasta} = req.query;
  let ops;
  if(authUser.role === 'admin'){
    ops = db.prepare('SELECT * FROM operaciones ORDER BY id DESC').all();
  }else{
    ops = db.prepare('SELECT * FROM operaciones WHERE user_id=? ORDER BY id DESC').all(authUser.id);
  }
  // Filtros
  if(tipo && tipo !== 'Todos') ops = ops.filter(o=>o.tipo===tipo);
  if(estado && estado !== 'Todos') ops = ops.filter(o=>o.estado===estado);
  if(cliente && cliente.trim() !== '') ops = ops.filter(o=> o.cliente.toLowerCase().includes(cliente.toLowerCase()));
  if(cajera_id && cajera_id !== 'Todos' && authUser.role === 'admin'){
    ops = ops.filter(o=> String(o.user_id) === String(cajera_id));
  }
  if(desde){
    const desdeDate = new Date(desde); if(!isNaN(desdeDate)){ ops = ops.filter(o=>{ if(!o.fecha_iso) return true; const f = new Date(o.fecha_iso); return f >= desdeDate; }); }
  }
  if(hasta){
    const hastaDate = new Date(hasta); if(!isNaN(hastaDate)){ hastaDate.setHours(23,59,59,999); ops = ops.filter(o=>{ if(!o.fecha_iso) return true; const f = new Date(o.fecha_iso); return f <= hastaDate; }); }
  }
  res.json(ops);
});

app.get('/api/estadisticas', (req,res)=>{
  const authUser = getUserById(req.query.user_id); if(!authUser) return res.status(401).json({error:'No autenticado'});
  const ops = authUser.role === 'admin' ? db.prepare('SELECT * FROM operaciones').all() : db.prepare('SELECT * FROM operaciones WHERE user_id=?').all(authUser.id);
  const hoy = new Date().toLocaleDateString('es-AR');
  const opsHoy = ops.filter(o=>o.fecha===hoy);
  res.json({
    total:ops.length,
    depositos:ops.filter(o=>o.tipo==='Depósito').length,
    retiros:ops.filter(o=>o.tipo==='Retiro').length,
    saldo:ops.filter(o=>o.tipo==='Depósito').reduce((a,b)=>a+b.monto,0)-ops.filter(o=>o.tipo==='Retiro').reduce((a,b)=>a+b.monto,0),
    totalDepositosMonto: ops.filter(o=>o.tipo==='Depósito').reduce((a,b)=>a+b.monto,0),
    totalRetirosMonto: ops.filter(o=>o.tipo==='Retiro').reduce((a,b)=>a+b.monto,0),
    opsHoy: opsHoy.length,
    saldoHoy: opsHoy.filter(o=>o.tipo==='Depósito').reduce((a,b)=>a+b.monto,0) - opsHoy.filter(o=>o.tipo==='Retiro').reduce((a,b)=>a+b.monto,0),
    pendientes: ops.filter(o=>o.estado==='Pendiente').length,
    revision: ops.filter(o=>o.estado==='Revisión').length,
  });
});

app.get('/api/cierres', (req,res)=>{
  const authUser = getUserById(req.query.user_id); if(!authUser) return res.status(401).json({error:'No autenticado'});
  if(authUser.role === 'admin') return res.json(db.prepare('SELECT * FROM cierres ORDER BY id DESC').all());
  return res.json(db.prepare('SELECT * FROM cierres WHERE user_id=? ORDER BY id DESC').all(authUser.id));
});

app.put('/api/operaciones/:numero/estado', (req,res)=>{
  const {estado,user_id}=req.body; const authUser = getUserById(user_id); if(!authUser) return res.status(401).json({error:'No autenticado'});
  const op=db.prepare('SELECT * FROM operaciones WHERE numero=?').get(req.params.numero); if(!op) return res.status(404).json({error:'No existe'});
  if(authUser.role !== 'admin' && String(op.user_id)!==String(authUser.id)) return res.status(403).json({error:'No podes modificar operaciones de otra cajera'});
  if(!['Confirmada','Pendiente','Revisión'].includes(estado)) return res.status(400).json({error:'Estado invalido'});
  db.prepare('UPDATE operaciones SET estado=? WHERE numero=?').run(estado,req.params.numero);
  registrarAuditoria({user_id: authUser.id, usuario: authUser.nombre, rol: authUser.role, accion: 'CAMBIAR ESTADO OPERACION', elemento: req.params.numero, detalle: `Op ${req.params.numero} a ${estado} por ${authUser.nombre}`});
  res.json({ok:true});
});

app.delete('/api/operaciones/:numero', (req,res)=>{
  const authUser = getUserById(req.query.user_id); if(!authUser) return res.status(401).json({error:'No autenticado'});
  const op = db.prepare('SELECT * FROM operaciones WHERE numero=?').get(req.params.numero); if(!op) return res.status(404).json({error:'No existe'});
  if(authUser.role !== 'admin' && String(op.user_id)!==String(authUser.id)) return res.status(403).json({error:'No podes borrar operaciones de otra cajera'});
  if(op.comprobante_file){ const p = path.join(__dirname,'uploads',op.comprobante_file); if(fs.existsSync(p)) try{ fs.unlinkSync(p); }catch{} }
  db.prepare('DELETE FROM operaciones WHERE numero=?').run(req.params.numero);
  registrarAuditoria({user_id: authUser.id, usuario: authUser.nombre, rol: authUser.role, accion: 'BORRAR OPERACION', elemento: req.params.numero, detalle: `Borrada op ${op.numero} cliente ${op.cliente} $${op.monto} por ${authUser.nombre}`});
  res.json({ok:true});
});

app.post('/api/operaciones', upload.single('comprobante_file'), (req,res)=>{
  try{
    const {cliente,cliente_id,tipo,monto,medio,banco,observaciones,estado,user_id}=req.body;
    const authUser = getUserById(user_id); if(!authUser) return res.status(401).json({error:'No autenticado'});
    if(!monto || isNaN(Number(monto))) return res.status(400).json({error:'Monto invalido'});
    const montoNum = Number(monto); if(montoNum <= 0) return res.status(400).json({error:'Monto debe ser mayor a 0'}); if(montoNum > 100000000) return res.status(400).json({error:'Monto demasiado grande'});
    if(!['Depósito','Retiro'].includes(tipo)) return res.status(400).json({error:'Tipo invalido'});
    let clienteFinal = cliente ? cliente.trim() : 'CLIENTE_GENERAL'; if(clienteFinal.length < 2) clienteFinal = 'CLIENTE_GENERAL';
    let clienteIdFinal = null;
    if(cliente_id && cliente_id !== '' && cliente_id !== 'null'){
      clienteIdFinal = Number(cliente_id); if(!isNaN(clienteIdFinal)){
        const cli = db.prepare('SELECT codigo FROM clientes WHERE id=?').get(clienteIdFinal); if(!cli) return res.status(400).json({error:'Cliente seleccionado no existe'}); clienteFinal = cli.codigo;
      } else clienteIdFinal = null;
    }
    const numero=`${Math.floor(100000+Math.random()*900000)}`;
    const now = new Date(); const fecha=now.toLocaleDateString('es-AR'); const hora=now.toLocaleTimeString('es-AR',{hour:'2-digit',minute:'2-digit'}); const fecha_iso = now.toISOString();
    db.prepare(`INSERT INTO operaciones (numero,cliente_id,cliente,tipo,monto,fecha,hora,estado,medio,banco,comprobante_file,cajera,user_id,observaciones,fecha_iso) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(numero,clienteIdFinal,clienteFinal,tipo,montoNum,fecha,hora,estado||'Confirmada',medio||'Transferencia',banco||'',req.file?req.file.filename:'',authUser.nombre,authUser.id,observaciones?observaciones.trim().substring(0,500):'',fecha_iso);
    registrarAuditoria({user_id: authUser.id, usuario: authUser.nombre, rol: authUser.role, accion: 'CREAR OPERACION', elemento: numero, detalle: `Creada op ${numero} cliente ${clienteFinal} tipo ${tipo} $${montoNum} por ${authUser.nombre}`});
    res.json({ok:true,numero});
  }catch(e){ console.error(e); if(e.message.includes('Solo imagenes')) return res.status(400).json({error:e.message}); res.status(500).json({error:e.message}); }
});

// ETAPA 2: EDITAR OPERACION
app.put('/api/operaciones/:numero', upload.single('comprobante_file'), (req,res)=>{
  try{
    const authUser = getUserById(req.body.user_id || req.query.user_id); if(!authUser) return res.status(401).json({error:'No autenticado'});
    const op = db.prepare('SELECT * FROM operaciones WHERE numero=?').get(req.params.numero); if(!op) return res.status(404).json({error:'Operacion no existe'});
    if(authUser.role !== 'admin' && String(op.user_id) !== String(authUser.id)) return res.status(403).json({error:'Solo podes editar tus propias operaciones'});
    const {cliente, cliente_id, tipo, monto, medio, banco, estado, observaciones} = req.body;
    let clienteFinal = op.cliente; let clienteIdFinal = op.cliente_id;
    if(cliente_id !== undefined){
      if(cliente_id === '' || cliente_id === 'null' || cliente_id === null){ clienteIdFinal = null; }
      else {
        const cid = Number(cliente_id); if(isNaN(cid)) return res.status(400).json({error:'cliente_id invalido'});
        const cli = db.prepare('SELECT codigo FROM clientes WHERE id=?').get(cid); if(!cli) return res.status(400).json({error:'Cliente no existe'}); clienteIdFinal = cid; clienteFinal = cli.codigo;
      }
    }
    if(cliente && cliente.trim() !== '' && !cliente_id) clienteFinal = cliente.trim();
    const tipoFinal = tipo && ['Depósito','Retiro'].includes(tipo) ? tipo : op.tipo;
    let montoFinal = op.monto; if(monto !== undefined){ const m = Number(monto); if(isNaN(m) || m <= 0) return res.status(400).json({error:'Monto invalido'}); if(m > 100000000) return res.status(400).json({error:'Monto demasiado grande'}); montoFinal = m; }
    const medioFinal = medio || op.medio; const bancoFinal = banco || op.banco;
    const estadoFinal = estado && ['Confirmada','Pendiente','Revisión'].includes(estado) ? estado : op.estado;
    const obsFinal = observaciones !== undefined ? observaciones.trim().substring(0,500) : op.observaciones;
    let comprobanteFinal = op.comprobante_file;
    if(req.file){ if(op.comprobante_file){ const old = path.join(__dirname,'uploads',op.comprobante_file); if(fs.existsSync(old)) try{ fs.unlinkSync(old); }catch{} } comprobanteFinal = req.file.filename; }

    db.prepare(`UPDATE operaciones SET cliente_id=?, cliente=?, tipo=?, monto=?, medio=?, banco=?, estado=?, observaciones=?, comprobante_file=? WHERE numero=?`).run(clienteIdFinal, clienteFinal, tipoFinal, montoFinal, medioFinal, bancoFinal, estadoFinal, obsFinal, comprobanteFinal, req.params.numero);
    registrarAuditoria({user_id: authUser.id, usuario: authUser.nombre, rol: authUser.role, accion: 'EDITAR OPERACION', elemento: req.params.numero, detalle: `Editada op ${req.params.numero} antes $${op.monto} ${op.tipo} ${op.cliente} -> ahora $${montoFinal} ${tipoFinal} ${clienteFinal} por ${authUser.nombre}`});
    res.json({ok:true});
  }catch(e){ console.error(e); res.status(500).json({error:e.message}); }
});

app.post('/api/cierre', (req,res)=>{
  try{
    let {user_id,arqueo_real}=req.body; const authUser = getUserById(user_id); if(!authUser) return res.status(401).json({error:'No autenticado'});
    if(arqueo_real === undefined || arqueo_real === null || String(arqueo_real).trim() === '') return res.status(400).json({error:'Debes ingresar arqueo real'});
    const arqueoNum = Number(arqueo_real); if(Number.isNaN(arqueoNum)) return res.status(400).json({error:'Arqueo debe ser numero'}); if(arqueoNum < 0) return res.status(400).json({error:'Arqueo no puede ser negativo'});
    const ops = authUser.role === 'admin' ? db.prepare('SELECT * FROM operaciones').all() : db.prepare('SELECT * FROM operaciones WHERE user_id=?').all(authUser.id);
    if(ops.length===0) return res.status(400).json({error:'No hay operaciones para cerrar'});
    const rec=ops.filter(o=>o.tipo==='Depósito').reduce((a,b)=>a+b.monto,0); const ent=ops.filter(o=>o.tipo==='Retiro').reduce((a,b)=>a+b.monto,0);
    const saldoSistema = rec - ent; const diferencia = arqueoNum - saldoSistema; let estadoArqueo = 'CAJA OK'; if(diferencia < 0) estadoArqueo = 'FALTANTE'; if(diferencia > 0) estadoArqueo = 'SOBRANTE';
    const info = db.prepare('INSERT INTO cierres (fecha,total_recibido,total_entregado,saldo,saldo_sistema,arqueo_real,diferencia,estado_arqueo,total_ops,cajera,user_id,detalle) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)').run(new Date().toISOString(),rec,ent,saldoSistema,saldoSistema,arqueoNum,diferencia,estadoArqueo,ops.length,authUser.nombre,authUser.id,JSON.stringify(ops));
    if(authUser.role === 'admin') db.exec('DELETE FROM operaciones'); else db.prepare('DELETE FROM operaciones WHERE user_id=?').run(authUser.id);
    registrarAuditoria({user_id: authUser.id, usuario: authUser.nombre, rol: authUser.role, accion: 'CERRAR TURNO', elemento: `CIERRE-${info.lastInsertRowid}`, detalle: `Cierre ${authUser.nombre} ID ${info.lastInsertRowid} ops ${ops.length} saldo ${saldoSistema} arqueo ${arqueoNum} dif ${diferencia} ${estadoArqueo}`});
    res.json({ok:true, saldo_sistema: saldoSistema, arqueo_real: arqueoNum, diferencia, estado_arqueo: estadoArqueo});
  }catch(e){ console.error(e); res.status(500).json({error:e.message}); }
});

app.delete('/api/cierres/:id', (req,res)=>{
  const authUser = getUserById(req.query.user_id); if(!authUser) return res.status(401).json({error:'No autenticado'});
  const c=db.prepare('SELECT * FROM cierres WHERE id=?').get(req.params.id); if(!c) return res.status(404).json({error:'No existe'});
  if(authUser.role !== 'admin' && String(c.user_id)!==String(authUser.id)) return res.status(403).json({error:'No podes borrar cierres de otra cajera'});
  db.prepare('DELETE FROM cierres WHERE id=?').run(req.params.id);
  registrarAuditoria({user_id: authUser.id, usuario: authUser.nombre, rol: authUser.role, accion: 'BORRAR CIERRE', elemento: `CIERRE-${req.params.id}`, detalle: `Borrado cierre ${req.params.id} de ${c.cajera} por ${authUser.nombre}`});
  res.json({ok:true});
});

app.delete('/api/cierres', (req,res)=>{
  const authUser = getUserById(req.query.user_id); if(!authUser) return res.status(401).json({error:'No autenticado'});
  const count = authUser.role === 'admin' ? db.prepare('SELECT COUNT(*) as c FROM cierres').get().c : db.prepare('SELECT COUNT(*) as c FROM cierres WHERE user_id=?').get(authUser.id).c;
  if(authUser.role === 'admin') db.exec('DELETE FROM cierres'); else db.prepare('DELETE FROM cierres WHERE user_id=?').run(authUser.id);
  registrarAuditoria({user_id: authUser.id, usuario: authUser.nombre, rol: authUser.role, accion: 'BORRAR HISTORIAL', elemento: authUser.role==='admin' ? 'TODOS LOS CIERRES' : `HISTORIAL DE ${authUser.nombre}`, detalle: `Borrado historial: ${count} cierres por ${authUser.nombre}`});
  res.json({ok:true});
});

app.get('/api/auditoria', (req,res)=>{
  const authUser = getUserById(req.query.user_id); if(!authUser) return res.status(401).json({error:'No autenticado'});
  if(authUser.role !== 'admin') return res.status(403).json({error:'Solo admin ve auditoria'});
  const {usuario, accion, fecha} = req.query;
  let aud = db.prepare('SELECT * FROM auditoria ORDER BY id DESC LIMIT 500').all();
  if(usuario) aud = aud.filter(a=>a.usuario.toLowerCase().includes(usuario.toLowerCase()));
  if(accion && accion !== 'Todas') aud = aud.filter(a=>a.accion.includes(accion));
  if(fecha) aud = aud.filter(a=>a.fecha===fecha);
  res.json(aud);
});

app.post('/api/reset-sistema', (req,res)=>{
  const {user_id, password_confirm}=req.body; const authUser = getUserById(user_id); if(!authUser) return res.status(401).json({error:'No autenticado'});
  if(authUser.role !== 'admin') return res.status(403).json({error:'Solo admin puede resetear'});
  if(password_confirm!=='RESET TOTAL') return res.status(400).json({error:'Debes escribir RESET TOTAL'});
  const counts = {ops: db.prepare('SELECT COUNT(*) as c FROM operaciones').get().c, cierres: db.prepare('SELECT COUNT(*) as c FROM cierres').get().c, auditoria: db.prepare('SELECT COUNT(*) as c FROM auditoria').get().c };
  db.exec('DELETE FROM operaciones'); db.exec('DELETE FROM cierres'); db.exec('DELETE FROM auditoria'); db.exec('DELETE FROM sqlite_sequence WHERE name IN ("operaciones","cierres","auditoria")');
  try{ const files = fs.readdirSync('uploads'); for(const f of files){ try{ fs.unlinkSync(path.join('uploads', f)); }catch{} } }catch{}
  const now = new Date(); db.prepare(`INSERT INTO auditoria (fecha_iso, fecha, hora, user_id, usuario, rol, accion, elemento, detalle) VALUES (?,?,?,?,?,?,?,?,?)`).run(now.toISOString(), now.toLocaleDateString('es-AR'), now.toLocaleTimeString('es-AR'), authUser.id, authUser.nombre, authUser.role, 'RESET SISTEMA TOTAL', 'SISTEMA', `Reset por ${authUser.nombre}: ${counts.ops} ops, ${counts.cierres} cierres, ${counts.auditoria} auditorias`);
  res.json({ok:true, borrados: counts});
});

app.get('/api/health', (req,res)=> res.json({ok:true}));

app.listen(PORT, ()=> console.log(`\n>>> BACKEND ETAPA 2 OK http://localhost:${PORT}\n>>> Con EDITAR CLIENTE + EDITAR OPERACION + FILTROS FECHA/CAJERA/TIPO + ESTADISTICAS COMPLETAS\n`));
