@echo off
echo RESTAURANDO BACKUP ETAPA 2 OK...
copy /Y "Server-Con-Auditoria.js" "D:\CasinoControl\backend\Server-Con-Auditoria.js"
copy /Y "App.jsx" "D:\CasinoControl\frontend\src\App.jsx"
echo Backup restaurado! Ahora inicia con INICIAR-CASINO.bat
pause
